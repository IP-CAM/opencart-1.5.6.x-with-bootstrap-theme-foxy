<?php 


/**
* Simple menu module
*/
class MenuModule extends ModuleCore 
{
	
	function __construct() {}

	public function installDatabase()
	{
		echo "installing db";
	}

	public function uninstallDatabase()
	{
		echo "uninstalling db";
	}


	public function removeFiles()
	{
		echo "removing files";
	}
}